package com.example.call

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.telecom.TelecomManager
import android.util.Log
import androidx.core.content.ContextCompat

/**
 * Voice-call controls for RJNX Jarvis.
 *
 * Uses Android TelecomManager for managed SIM calls and AudioManager for
 * communication audio routing. Full call control is subject to Android/OEM
 * permissions and role restrictions.
 */
class CallControlManager(private val context: Context) {

    private val telecom: TelecomManager?
        get() = context.getSystemService(TelecomManager::class.java)

    private val audio: AudioManager?
        get() = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    fun handleCommand(command: String): String? {
        val lower = command.lowercase().trim()

        return when {
            isAnswerCommand(lower) -> answerCall()
            isRejectCommand(lower) -> rejectCall()
            isEndCommand(lower) -> endCall()
            isSpeakerOnCommand(lower) -> setSpeaker(true)
            isSpeakerOffCommand(lower) -> setSpeaker(false)
            isMuteCommand(lower) -> setMute(true)
            isUnmuteCommand(lower) -> setMute(false)
            isBluetoothOnCommand(lower) -> setBluetoothRoute(true)
            isBluetoothOffCommand(lower) -> setBluetoothRoute(false)
            isCallStatusCommand(lower) -> callStatus()
            else -> null
        }
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) ==
            PackageManager.PERMISSION_GRANTED

    private fun answerCall(): String {
        if (!hasPermission(Manifest.permission.ANSWER_PHONE_CALLS)) {
            return "I need the Answer Phone Calls permission to answer calls."
        }

        val manager = telecom ?: return "Phone call controls are not available on this device."

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                manager.acceptRingingCall()
                "Answering the call."
            } else {
                "Call answering is not supported on this Android version."
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Answer call permission/security error", e)
            "Android blocked call answering. Please allow the Answer Phone Calls permission."
        } catch (e: Exception) {
            Log.e(TAG, "Answer call error", e)
            "I couldn't answer the call."
        }
    }

    private fun rejectCall(): String {
        // endCall() rejects a ringing foreground call, so the same action
        // covers both "reject" and "decline".
        return endCall(rejecting = true)
    }

    private fun endCall(rejecting: Boolean = false): String {
        if (!hasPermission(Manifest.permission.ANSWER_PHONE_CALLS)) {
            return "I need the Answer Phone Calls permission to control calls."
        }

        val manager = telecom ?: return "Phone call controls are not available on this device."

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val ended = manager.endCall()
                if (ended) {
                    if (rejecting) "Rejecting the call." else "Ending the call."
                } else {
                    "There is no active call to control."
                }
            } else {
                "Call ending is not supported on this Android version."
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "End call permission/security error", e)
            "Android blocked call control. Please allow the Answer Phone Calls permission."
        } catch (e: Exception) {
            Log.e(TAG, "End call error", e)
            "I couldn't control the call."
        }
    }

    private fun setSpeaker(enabled: Boolean): String {
        val manager = audio ?: return "Audio controls are unavailable."

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val speaker = manager.availableCommunicationDevices
                    .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }

                if (enabled) {
                    if (speaker != null && manager.setCommunicationDevice(speaker)) {
                        "Speaker on."
                    } else {
                        "I couldn't switch the call to speaker."
                    }
                } else {
                    manager.clearCommunicationDevice()
                    "Speaker off."
                }
            } else {
                @Suppress("DEPRECATION")
                manager.isSpeakerphoneOn = enabled
                if (enabled) "Speaker on." else "Speaker off."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Speaker control error", e)
            "I couldn't change the speaker setting."
        }
    }

    private fun setMute(enabled: Boolean): String {
        val manager = audio ?: return "Audio controls are unavailable."

        return try {
            @Suppress("DEPRECATION")
            manager.isMicrophoneMute = enabled
            if (enabled) "Microphone muted." else "Microphone unmuted."
        } catch (e: Exception) {
            Log.e(TAG, "Mute control error", e)
            "I couldn't change the microphone mute state."
        }
    }

    private fun setBluetoothRoute(enabled: Boolean): String {
        val manager = audio ?: return "Audio controls are unavailable."

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !hasPermission(Manifest.permission.BLUETOOTH_CONNECT)
        ) {
            return "I need Bluetooth permission to control Bluetooth call audio."
        }

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (enabled) {
                    val bluetooth = manager.availableCommunicationDevices
                        .firstOrNull {
                            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                                it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
                        }

                    if (bluetooth != null && manager.setCommunicationDevice(bluetooth)) {
                        "Bluetooth audio selected."
                    } else {
                        "No connected Bluetooth headset is available."
                    }
                } else {
                    manager.clearCommunicationDevice()
                    "Bluetooth call audio disconnected."
                }
            } else {
                @Suppress("DEPRECATION")
                if (enabled) {
                    manager.startBluetoothSco()
                    manager.isBluetoothScoOn = true
                    "Bluetooth audio selected."
                } else {
                    manager.isBluetoothScoOn = false
                    manager.stopBluetoothSco()
                    "Bluetooth call audio disconnected."
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Bluetooth route error", e)
            "I couldn't change the Bluetooth call audio route."
        }
    }

    private fun callStatus(): String {
        if (!hasPermission(Manifest.permission.READ_PHONE_STATE)) {
            return "I need Phone State permission to check call status."
        }

        val manager = telecom ?: return "Phone call controls are unavailable."

        return try {
            if (manager.isInCall) "There is an active phone call."
            else "There is no active phone call."
        } catch (e: SecurityException) {
            "Android blocked access to phone call status."
        } catch (e: Exception) {
            "I couldn't check the call status."
        }
    }

    private fun isAnswerCommand(s: String): Boolean =
        s.contains("answer the call") ||
            s == "answer" ||
            s.contains("pick up the call") ||
            s.contains("accept the call") ||
            s.contains("accept call")

    private fun isRejectCommand(s: String): Boolean =
        s.contains("reject the call") ||
            s.contains("decline the call") ||
            s.contains("reject call") ||
            s.contains("decline call")

    private fun isEndCommand(s: String): Boolean =
        s.contains("end the call") ||
            s.contains("end call") ||
            s.contains("cut the call") ||
            s.contains("cut call") ||
            s.contains("hang up") ||
            s.contains("disconnect the call")

    private fun isSpeakerOnCommand(s: String): Boolean =
        s.contains("speaker on") ||
            s.contains("turn on speaker") ||
            s.contains("put it on speaker") ||
            s.contains("loudspeaker on")

    private fun isSpeakerOffCommand(s: String): Boolean =
        s.contains("speaker off") ||
            s.contains("turn off speaker") ||
            s.contains("speakerphone off")

    private fun isMuteCommand(s: String): Boolean =
        s.contains("mute the call") ||
            s.contains("mute call") ||
            s == "mute"

    private fun isUnmuteCommand(s: String): Boolean =
        s.contains("unmute the call") ||
            s.contains("unmute call") ||
            s == "unmute"

    private fun isBluetoothOnCommand(s: String): Boolean =
        s.contains("bluetooth on") ||
            s.contains("use bluetooth") ||
            s.contains("connect bluetooth")

    private fun isBluetoothOffCommand(s: String): Boolean =
        s.contains("bluetooth off") ||
            s.contains("disconnect bluetooth")

    private fun isCallStatusCommand(s: String): Boolean =
        s == "call status" ||
            s.contains("am i on a call") ||
            s.contains("is there an active call") ||
            s.contains("is a call active")

    companion object {
        private const val TAG = "CallControlManager"
    }
}
